
package ControladoresyRepos;
import modelos.Estudiante;

public class ControladorEstudiante {
    private ControladorPrincipal controladorPrincipal;
    private RepositorioLibro libros;
    
    public ControladorEstudiante(ControladorPrincipal controladorPrincipal, RepositorioLibro libros){
        this.controladorPrincipal = controladorPrincipal;
        this.libros = libros;
    }
    
    public Libro[] obtenerCatalogoLibros(){
        return libros.todosLosLibros();
    }
    
    
    public void CerrarSesion(){
        
    }
}
